# Katana Chocolate Controller (Android / Kotlin)

**Purpose:** a tiny, fully-offline **MIDI bridge** for this rig:

- **Foot controller:** M‑VAVE Chocolate (regular) → **BLE‑MIDI IN**
- **Amp:** BOSS Katana‑50 MkII (50W) → **USB OTG (Android as USB Host)**
- App does: **BLE‑MIDI IN → Mapper → USB‑MIDI OUT (Program Change)**

---

## Fixed mapping (required)

Human (base‑1) program numbers:

| Chocolate Button | Katana Target | PC shown (base‑1) |
|---|---|---|
| A | BANK A CH1 | 1 |
| B | BANK A CH2 | 2 |
| C | BANK B CH1 | 6 |
| D | BANK B CH2 | 7 |

### PC numbering mode (setting)

- **Send Base‑0 (subtract 1)** = **ON (default)**  
  Sends **0 / 1 / 5 / 6** for PC shown **1 / 2 / 6 / 7** (matches the “1 (00h)” style mapping).

- **Send Base‑0 (subtract 1)** = OFF  
  Sends **1 / 2 / 6 / 7**.

### MIDI channel (setting)

- Default **CH1**
- Selectable **CH1–CH4**

---

## USB output paths (required)

The app will try:

1) **Android MIDI API** (if the Katana enumerates as a MIDI device)  
2) Fallback: **USB Host “class-compliant USB‑MIDI” bulk endpoint sender**

UI shows which path is active.

---

## Build (APK)

### Android Studio (recommended)

1. Open the folder `KatanaChocolateController/` in Android Studio.
2. Let Gradle sync.
3. **Build APK**
   - Debug: `Build > Build Bundle(s) / APK(s) > Build APK(s)`
   - Or terminal: `./gradlew assembleDebug`

The debug APK will be at:

`app/build/outputs/apk/debug/app-debug.apk`

### Command line

```bash
./gradlew assembleDebug
```

---

## Notes / Troubleshooting

- **USB permission**: when you plug the Katana via OTG, Android may prompt for USB permission — accept it.
- **USB auto-launch filter** (optional):  
  `app/src/main/res/xml/device_filter.xml` is intentionally left as a placeholder because Android’s USB filter requires **vendorId/productId**.  
  If you add your Katana VID/PID there, Android can launch the app automatically when you plug it in.
- **BLE scan permissions**: Android 12+ uses `BLUETOOTH_SCAN` and `BLUETOOTH_CONNECT`. If you deny them, scanning won’t work.

---

## Internal mapping table (actual outgoing MIDI bytes)

Outgoing message is a **Program Change**:  
`status = 0xC0 | (channel-1)` and `data = program`.

Examples (default CH1, Send Base‑0 ON):
- A → bytes `[0xC0, 0x00]`
- B → bytes `[0xC0, 0x01]`
- C → bytes `[0xC0, 0x05]`
- D → bytes `[0xC0, 0x06]`
