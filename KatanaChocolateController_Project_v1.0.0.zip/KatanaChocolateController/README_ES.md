# Katana Chocolate Controller (Android / Kotlin) – Guía rápida (ES)

## Qué hace
Puente MIDI **offline**:

**M‑VAVE Chocolate (BLE‑MIDI) → Android → BOSS Katana MkII (USB OTG)**

## Mapeo fijo
La app convierte los botones A/B/C/D en Program Change hacia el Katana:

- **A → PC mostrado 1**
- **B → PC mostrado 2**
- **C → PC mostrado 6**
- **D → PC mostrado 7**

### Modo Base‑0 / Base‑1
En Settings:
- **Send Base‑0 (subtract 1)** = **ON (por defecto)** → envía **0/1/5/6**
- OFF → envía **1/2/6/7**

## Cómo generar el APK (Debug)

### Opción 1: Android Studio (recomendado)
1. Abre la carpeta **KatanaChocolateController/**
2. Espera a que sincronice Gradle
3. Ve a **Build → Build Bundle(s)/APK(s) → Build APK(s)**
4. El APK queda en:
   `app/build/outputs/apk/debug/app-debug.apk`

### Opción 2: Script (más rápido)
1. Abre el proyecto al menos una vez en Android Studio (esto crea `local.properties` apuntando al SDK).
2. Ejecuta:

**Windows (PowerShell):**
`tools\build_debug_apk_windows.ps1`

**Mac/Linux:**
`tools/build_debug_apk_mac_linux.sh`

## Uso
- Conecta el **Katana** por **USB OTG**.
- Acepta el prompt de **USB permission** si aparece.
- En la app, conecta por BLE al **Chocolate**.
- Presiona A/B/C/D (o usa los botones de prueba) y verás los envíos en el log.
