package com.example.katanachocolatecontroller

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

interface MidiOut {
    fun sendProgramChange(channel0: Int, program: Int): Boolean
    fun close()
}

class UsbKatanaManager(private val ctx: Context) {
    companion object {
        const val ACTION_USB_PERMISSION = "com.example.katanachocolatecontroller.USB_PERMISSION"
    }

    private val usbManager = ctx.getSystemService(UsbManager::class.java)
    private val midiManager = ctx.getSystemService(MidiManager::class.java)

    private val _state = MutableStateFlow<UsbState>(UsbState.NotDetected)
    val state: StateFlow<UsbState> = _state.asStateFlow()

    private val _outputMode = MutableStateFlow(OutputMode.None)
    val outputMode: StateFlow<OutputMode> = _outputMode.asStateFlow()

    var currentOutput: MidiOut? = null
        private set

    private var currentUsb: UsbDevice? = null

    fun refresh(log: (String) -> Unit) {
        val candidate = findMidiUsbDevice()
        if (candidate == null) {
            currentUsb = null
            currentOutput?.close()
            currentOutput = null
            _outputMode.value = OutputMode.None
            _state.value = UsbState.NotDetected
            log("USB: no MIDI-like device detected")
            return
        }
        connect(candidate, log)
    }

    fun handleUsbIntent(intent: Intent, log: (String) -> Unit) {
        when (intent.action) {
            UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                val dev = intent.getParcelableExtraCompat<UsbDevice>(UsbManager.EXTRA_DEVICE)
                if (dev != null) {
                    log("USB attached: " + (dev.productName ?: "device"))
                    connect(dev, log)
                }
            }
            UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                val dev = intent.getParcelableExtraCompat<UsbDevice>(UsbManager.EXTRA_DEVICE)
                if (dev != null && currentUsb?.deviceId == dev.deviceId) {
                    log("USB detached: closing output")
                    closeCurrent()
                    _state.value = UsbState.NotDetected
                }
            }
            ACTION_USB_PERMISSION -> {
                val dev = intent.getParcelableExtraCompat<UsbDevice>(UsbManager.EXTRA_DEVICE)
                val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                if (dev != null) {
                    if (granted) {
                        log("USB permission granted")
                        connect(dev, log)
                    } else {
                        log("USB permission denied")
                        _state.value = UsbState.NoPermission
                    }
                }
            }
        }
    }

    private fun closeCurrent() {
        try { currentOutput?.close() } catch (_: Throwable) {}
        currentOutput = null
        currentUsb = null
        _outputMode.value = OutputMode.None
    }

    private fun connect(dev: UsbDevice, log: (String) -> Unit) {
        currentUsb = dev
        if (!usbManager.hasPermission(dev)) {
            requestPermission(dev, log)
            _state.value = UsbState.NoPermission
            _outputMode.value = OutputMode.None
            return
        }

        // Close old output before reconnect.
        currentOutput?.close()
        currentOutput = null
        _outputMode.value = OutputMode.None

        // Try Android MIDI API first (if OS exposes it as a USB MIDI device)
        val midiInfo = findMidiDeviceInfoForUsb(dev)
        if (midiInfo != null) {
            log("USB: using Android MIDI API")
            openWithAndroidMidiApi(midiInfo, dev, log)
            return
        }

        log("USB: Android MIDI API device not found, trying USB Host driver")
        val host = UsbHostMidiOut.open(usbManager, dev, log)
        if (host != null) {
            currentOutput = host
            _outputMode.value = OutputMode.UsbHostDriver
            _state.value = UsbState.Connected(host.description)
        } else {
            _outputMode.value = OutputMode.None
            _state.value = UsbState.Error("Failed to open USB MIDI endpoint")
        }
    }

    private fun requestPermission(dev: UsbDevice, log: (String) -> Unit) {
        val pi = PendingIntent.getBroadcast(
            ctx,
            dev.deviceId,
            Intent(ACTION_USB_PERMISSION),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        log("USB: requesting permission…")
        usbManager.requestPermission(dev, pi)
    }

    private fun findMidiUsbDevice(): UsbDevice? {
        // Heuristic: pick the first USB device that exposes an Audio/MIDI streaming interface.
        return usbManager.deviceList.values.firstOrNull { looksLikeUsbMidi(it) }
            ?: usbManager.deviceList.values.firstOrNull()
    }

    private fun looksLikeUsbMidi(dev: UsbDevice): Boolean {
        for (i in 0 until dev.interfaceCount) {
            val intf = dev.getInterface(i)
            if (intf.interfaceClass == UsbConstants.USB_CLASS_AUDIO &&
                intf.interfaceSubclass == 3 /* MIDI streaming */) {
                return true
            }
        }
        return false
    }

    private fun findMidiDeviceInfoForUsb(dev: UsbDevice): MidiDeviceInfo? {
        val list = midiManager.devices
        return list.firstOrNull { info ->
            if (info.type != MidiDeviceInfo.TYPE_USB) return@firstOrNull false
            val props = info.properties
            val usb = if (Build.VERSION.SDK_INT >= 33) {
                props.getParcelable(MidiDeviceInfo.PROPERTY_USB_DEVICE, UsbDevice::class.java)
            } else {
                @Suppress("DEPRECATION")
                props.getParcelable(MidiDeviceInfo.PROPERTY_USB_DEVICE) as? UsbDevice
            }
            usb != null && usb.deviceId == dev.deviceId && usb.vendorId == dev.vendorId && usb.productId == dev.productId
        }
    }

    private fun openWithAndroidMidiApi(info: MidiDeviceInfo, usbDev: UsbDevice, log: (String) -> Unit) {
        val ht = HandlerThread("MidiOpenThread").apply { start() }
        val handler = Handler(ht.looper)

        midiManager.openDevice(info, { midiDevice: MidiDevice? ->
            if (midiDevice == null) {
                log("Android MIDI API: openDevice returned null, falling back to USB Host driver")
                ht.quitSafely()
                openHostFallback(usbDev, log)
                return@openDevice
            }

            val port = (0 until info.inputPortCount)
                .mapNotNull { idx -> midiDevice.openInputPort(idx) }
                .firstOrNull()

            if (port == null) {
                log("Android MIDI API: no input port available, falling back to USB Host driver")
                try { midiDevice.close() } catch (_: Throwable) {}
                ht.quitSafely()
                openHostFallback(usbDev, log)
                return@openDevice
            }

            currentOutput = AndroidMidiApiOut(midiDevice, port)
            _outputMode.value = OutputMode.AndroidMidiApi

            val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "USB MIDI"
            _state.value = UsbState.Connected("Android MIDI API: " + name)
            log("Android MIDI API: connected")
        }, handler)
    }

    private fun openHostFallback(usbDev: UsbDevice, log: (String) -> Unit) {
        val host = UsbHostMidiOut.open(usbManager, usbDev, log)
        if (host != null) {
            currentOutput = host
            _outputMode.value = OutputMode.UsbHostDriver
            _state.value = UsbState.Connected(host.description)
        } else {
            _outputMode.value = OutputMode.None
            _state.value = UsbState.Error("Failed to open Katana (MIDI API + Host driver)")
        }
    }
}

class AndroidMidiApiOut(
    private val device: MidiDevice,
    private val inputPort: MidiInputPort
) : MidiOut {
    override fun sendProgramChange(channel0: Int, program: Int): Boolean {
        val status = (0xC0 or (channel0 and 0x0F)).toByte()
        val prog = (program and 0x7F).toByte()
        val msg = byteArrayOf(status, prog)
        return try {
            inputPort.send(msg, 0, msg.size)
            true
        } catch (_: Throwable) {
            false
        }
    }

    override fun close() {
        try { inputPort.close() } catch (_: Throwable) {}
        try { device.close() } catch (_: Throwable) {}
    }
}

class UsbHostMidiOut private constructor(
    private val connection: UsbDeviceConnection,
    private val intf: UsbInterface,
    private val outEp: UsbEndpoint,
    val description: String
) : MidiOut {

    companion object {
        fun open(usbManager: UsbManager, dev: UsbDevice, log: (String) -> Unit): UsbHostMidiOut? {
            val connection = usbManager.openDevice(dev) ?: return null

            val midiIntf = (0 until dev.interfaceCount)
                .map { dev.getInterface(it) }
                .firstOrNull { it.interfaceClass == UsbConstants.USB_CLASS_AUDIO && it.interfaceSubclass == 3 }

            val targetIntf = midiIntf ?: run {
                log("USB Host: no MIDI streaming interface found")
                connection.close()
                return null
            }

            if (!connection.claimInterface(targetIntf, true)) {
                log("USB Host: failed to claim interface")
                connection.close()
                return null
            }

            val outEp = (0 until targetIntf.endpointCount)
                .map { targetIntf.getEndpoint(it) }
                .firstOrNull {
                    it.direction == UsbConstants.USB_DIR_OUT &&
                        it.type == UsbConstants.USB_ENDPOINT_XFER_BULK
                }

            if (outEp == null) {
                log("USB Host: no BULK OUT endpoint found")
                try { connection.releaseInterface(targetIntf) } catch (_: Throwable) {}
                connection.close()
                return null
            }

            val desc = "USB Host driver: " +
                (dev.manufacturerName ?: "") + " " + (dev.productName ?: "USB MIDI")
            return UsbHostMidiOut(connection, targetIntf, outEp, desc.trim())
        }
    }

    override fun sendProgramChange(channel0: Int, program: Int): Boolean {
        // USB-MIDI event packet (4 bytes)
        // CIN 0xC = Program Change (2 bytes)
        val status = 0xC0 or (channel0 and 0x0F)
        val p = program and 0x7F
        val packet = byteArrayOf(
            0x0C.toByte(),
            status.toByte(),
            p.toByte(),
            0x00
        )
        return try {
            val sent = connection.bulkTransfer(outEp, packet, packet.size, 50)
            sent == packet.size
        } catch (_: Throwable) {
            false
        }
    }

    override fun close() {
        try { connection.releaseInterface(intf) } catch (_: Throwable) {}
        try { connection.close() } catch (_: Throwable) {}
    }
}

inline fun <reified T> Intent.getParcelableExtraCompat(name: String): T? {
    return if (Build.VERSION.SDK_INT >= 33) {
        getParcelableExtra(name, T::class.java)
    } else {
        @Suppress("DEPRECATION")
        getParcelableExtra(name) as? T
    }
}
