package com.example.katanachocolatecontroller

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.ParcelUuid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Minimal BLE-MIDI client:
 * - Scans for BLE MIDI service (03B80E5A-EDE8-4B33-A751-6CE34EC4C700)
 * - Subscribes to the MIDI I/O characteristic
 * - Extracts Program Change messages (0xC0..0xCF) from notifications
 *
 * NOTE: M-VAVE Chocolate (regular) typically sends Program Changes by default.
 */
class BleMidiClient(private val ctx: Context) {
    companion object {
        private val MIDI_SERVICE_UUID: UUID =
            UUID.fromString("03B80E5A-EDE8-4B33-A751-6CE34EC4C700")
        private val MIDI_CHAR_UUID: UUID =
            UUID.fromString("7772E5DB-3868-4112-A1A9-F2669D106BF3")
        private val CCCD_UUID: UUID =
            UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _state = MutableStateFlow<BleState>(BleState.Disconnected)
    val state: StateFlow<BleState> = _state.asStateFlow()

    private val _lastMessage = MutableStateFlow("—")
    val lastMessage: StateFlow<String> = _lastMessage.asStateFlow()

    private val _programChanges = MutableSharedFlow<ProgramChange>(extraBufferCapacity = 32)
    val programChanges: SharedFlow<ProgramChange> = _programChanges.asSharedFlow()

    private val btManager: BluetoothManager? = ctx.getSystemService(BluetoothManager::class.java)
    private val adapter: BluetoothAdapter? = btManager?.adapter
    private val scanner: BluetoothLeScanner? get() = adapter?.bluetoothLeScanner

    private var gatt: BluetoothGatt? = null
    private var midiChar: BluetoothGattCharacteristic? = null

    private var lastAddress: String? = null
    private val reconnectEnabled = AtomicBoolean(true)

    fun connectToLastKnown(address: String) {
        lastAddress = address
        reconnectEnabled.set(true)
        val dev = try {
            adapter?.getRemoteDevice(address)
        } catch (_: Throwable) {
            null
        }
        if (dev != null) {
            connect(dev)
        } else {
            startScanForAddress(address)
        }
    }

    suspend fun startScanAndConnectFirstMatch() {
        reconnectEnabled.set(true)
        startScanAndConnectFirst()
    }

    fun disconnect() {
        reconnectEnabled.set(false)
        try {
            gatt?.close()
        } catch (_: Throwable) {}
        gatt = null
        midiChar = null
        _state.value = BleState.Disconnected
    }

    @SuppressLint("MissingPermission")
    private fun startScanAndConnectFirst() {
        val sc = scanner ?: run {
            _state.value = BleState.Error("Bluetooth scanner not available")
            return
        }
        _state.value = BleState.Scanning

        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(MIDI_SERVICE_UUID))
            .build()

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val dev = result.device ?: return
                stopScanSafe(this)
                connect(dev)
            }

            override fun onScanFailed(errorCode: Int) {
                _state.value = BleState.Error("Scan failed: $errorCode")
            }
        }

        sc.startScan(listOf(filter), settings, cb)
    }

    @SuppressLint("MissingPermission")
    private fun startScanForAddress(address: String) {
        val sc = scanner ?: run {
            _state.value = BleState.Error("Bluetooth scanner not available")
            return
        }
        _state.value = BleState.Scanning

        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val dev = result.device ?: return
                if (dev.address.equals(address, ignoreCase = true)) {
                    stopScanSafe(this)
                    connect(dev)
                }
            }

            override fun onScanFailed(errorCode: Int) {
                _state.value = BleState.Error("Scan failed: $errorCode")
            }
        }

        // No filter to maximize chance to find by address.
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        sc.startScan(null, settings, cb)
    }

    @SuppressLint("MissingPermission")
    private fun stopScanSafe(cb: ScanCallback) {
        try {
            scanner?.stopScan(cb)
        } catch (_: Throwable) {}
    }

    @SuppressLint("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        lastAddress = device.address
        _state.value = BleState.Scanning
        try {
            gatt?.close()
        } catch (_: Throwable) {}
        gatt = null
        midiChar = null

        val newGatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            device.connectGatt(ctx, false, gattCb, BluetoothDevice.TRANSPORT_LE)
        } else {
            device.connectGatt(ctx, false, gattCb)
        }
        gatt = newGatt
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                _state.value = BleState.Error("GATT error status=$status")
                safeClose(gatt)
                maybeReconnect()
                return
            }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                _state.value = BleState.Disconnected
                safeClose(gatt)
                maybeReconnect()
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                _state.value = BleState.Error("Service discovery failed status=$status")
                safeClose(gatt)
                maybeReconnect()
                return
            }
            val service: BluetoothGattService? = gatt.getService(MIDI_SERVICE_UUID)
            val ch: BluetoothGattCharacteristic? = service?.getCharacteristic(MIDI_CHAR_UUID)
            if (ch == null) {
                _state.value = BleState.Error("BLE MIDI characteristic not found")
                safeClose(gatt)
                maybeReconnect()
                return
            }
            midiChar = ch
            val ok = gatt.setCharacteristicNotification(ch, true)
            if (!ok) {
                _state.value = BleState.Error("Failed to enable notifications")
                safeClose(gatt)
                maybeReconnect()
                return
            }
            val desc: BluetoothGattDescriptor? = ch.getDescriptor(CCCD_UUID)
            desc?.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            if (desc != null) {
                @Suppress("DEPRECATION")
                gatt.writeDescriptor(desc)
            }
            val name = (gatt.device.name ?: "MIDI Device")
            val addr = gatt.device.address
            _state.value = BleState.Connected(name = name, address = addr)
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            if (characteristic.uuid != MIDI_CHAR_UUID) return
            val bytes = characteristic.value ?: return
            val pcs = BleMidiParser.extractProgramChanges(bytes)
            if (pcs.isNotEmpty()) {
                _lastMessage.value = pcs.joinToString(" | ") { it.toString() }
                pcs.forEach { pc ->
                    scope.launch {
                        _programChanges.emit(pc)
                    }
                }
            } else {
                _lastMessage.value = "RX ${bytes.size} bytes"
            }
        }
    }

    private fun safeClose(g: BluetoothGatt) {
        try { g.close() } catch (_: Throwable) {}
    }

    private fun maybeReconnect() {
        if (!reconnectEnabled.get()) return
        val addr = lastAddress ?: return
        startScanForAddress(addr)
    }
}

object BleMidiParser {
    /**
     * BLE-MIDI packets include timestamp bytes (0x80..0xBF). Program Change status bytes are 0xC0..0xCF,
     * which are unambiguous (>= 0xC0), so we can safely scan for them.
     */
    fun extractProgramChanges(packet: ByteArray): List<ProgramChange> {
        val out = ArrayList<ProgramChange>(2)
        var i = 0
        while (i < packet.size - 1) {
            val b = packet[i].toInt() and 0xFF
            if (b in 0xC0..0xCF) {
                val channel0 = b and 0x0F
                val program = packet[i + 1].toInt() and 0x7F
                out.add(ProgramChange(channel0 = channel0, program = program))
                i += 2
                continue
            }
            i++
        }
        return out
    }
}
