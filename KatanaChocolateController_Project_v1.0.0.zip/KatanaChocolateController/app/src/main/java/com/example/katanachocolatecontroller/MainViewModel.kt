package com.example.katanachocolatecontroller

import android.app.Application
import android.content.Intent
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val settings = SettingsStore(app)
    private val ble = BleMidiClient(app)
    private val usb = UsbKatanaManager(app)

    private val router = MidiRouter(
        settings = settings,
        usbOutputProvider = { usb.currentOutput },
        log = ::log
    )

    private val _ui = MutableStateFlow(MainUiState())
    val ui: StateFlow<MainUiState> = _ui.asStateFlow()

    private val logDate = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    init {
        viewModelScope.launch {
            settings.state.collect { s ->
                _ui.value = _ui.value.copy(settings = s)
            }
        }
        viewModelScope.launch {
            ble.state.collect { st ->
                                _ui.value = _ui.value.copy(bleState = st)
                if (st is BleState.Connected) {
                    settings.setLastBleAddress(st.address)
                }
            }
        }
        viewModelScope.launch {
            usb.state.collect { st ->
                _ui.value = _ui.value.copy(usbState = st, outputMode = usb.outputMode.value)
            }
        }
        viewModelScope.launch {
            usb.outputMode.collect { om ->
                _ui.value = _ui.value.copy(outputMode = om)
            }
        }
        viewModelScope.launch {
            ble.lastMessage.collect { msg ->
                _ui.value = _ui.value.copy(lastBleMessage = msg)
            }
        }

        // Bridge: BLE-MIDI IN -> mapper -> USB-MIDI OUT
        viewModelScope.launch {
            ble.programChanges.collect { pc ->
                router.onIncomingProgramChange(pc)
            }
        }
    }

    fun log(message: String) {
        val ts = logDate.format(Date())
        val newEntry = "[$ts] $message"
        val newList = (listOf(newEntry) + _ui.value.eventLog).take(30)
        _ui.value = _ui.value.copy(eventLog = newList)
    }

    fun onBluetoothPermissionsResult(results: Map<String, Boolean>) {
        val denied = results.entries.filter { !it.value }.map { it.key }
        if (denied.isNotEmpty()) {
            log("Bluetooth permission denied: $denied")
        }
    }

    fun startBleAutoConnect() {
        viewModelScope.launch {
            val last = settings.getLastBleAddress()
            if (last != null) {
                log("BLE: auto-connecting to last device $last")
                ble.connectToLastKnown(last)
            } else {
                log("BLE: no saved device. Tap Scan to connect.")
            }
        }
    }

    fun scanBle() {
        viewModelScope.launch {
            ble.startScanAndConnectFirstMatch()
        }
    }

    fun disconnectBle() {
        viewModelScope.launch {
            ble.disconnect()
        }
    }

    fun onTestButton(button: ChocolateButton) {
        viewModelScope.launch {
            router.sendMappedProgramChange(button, source = "TEST")
        }
    }

    fun handleUsbIntent(intent: Intent) {
        usb.handleUsbIntent(intent) { msg -> log(msg) }
    }

    fun refreshUsb() {
        usb.refresh { msg -> log(msg) }
    }

    // Settings setters
    fun setMidiChannel(ch: Int) {
        viewModelScope.launch { settings.setMidiChannel(ch) }
    }

    fun setSendBaseZero(sendBaseZero: Boolean) {
        viewModelScope.launch { settings.setSendBaseZero(sendBaseZero) }
    }

    fun setDebounceMs(ms: Long) {
        viewModelScope.launch { settings.setDebounceMs(ms) }
    }

    fun resetDefaults() {
        viewModelScope.launch { settings.resetDefaults() }
    }

    fun saveBleAddress(address: String) {
        viewModelScope.launch { settings.setLastBleAddress(address) }
    }
}
