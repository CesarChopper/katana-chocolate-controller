package com.example.katanachocolatecontroller.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.katanachocolatecontroller.ChocolateButton
import com.example.katanachocolatecontroller.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    vm: MainViewModel,
    onBack: () -> Unit
) {
    val ui by vm.ui.collectAsState()
    val s = ui.settings

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("MIDI Channel (Katana)", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (ch in 1..4) {
                                Button(
                                    onClick = { vm.setMidiChannel(ch) },
                                    enabled = s.midiChannel != ch
                                ) {
                                    Text("CH$ch")
                                }
                            }
                        }
                    }
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Program Change numbering", style = MaterialTheme.typography.titleMedium)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Send Base-0 (subtract 1)")
                                Text(
                                    "ON: send 0/1/5/6 for PC shown 1/2/6/7",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Switch(
                                checked = s.sendBaseZero,
                                onCheckedChange = { vm.setSendBaseZero(it) }
                            )
                        }
                    }
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Debounce (ms)", style = MaterialTheme.typography.titleMedium)
                        Text(s.debounceMs.toString() + " ms")
                        Slider(
                            value = s.debounceMs.toFloat(),
                            onValueChange = { vm.setDebounceMs(it.toLong()) },
                            valueRange = 80f..150f
                        )
                    }
                }
            }

            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Mapping table (fixed)", style = MaterialTheme.typography.titleMedium)
                        val lines = mappingLines(midiChannel = s.midiChannel, sendBaseZero = s.sendBaseZero)
                        lines.forEach { line ->
                            Text(line, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.padding(2.dp))
                        }
                    }
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.resetDefaults() }) { Text("Reset to defaults") }
                }
            }
        }
    }
}

private fun mappingLines(midiChannel: Int, sendBaseZero: Boolean): List<String> {
    val ch = midiChannel.coerceIn(1, 4)
    val channel0 = ch - 1
    val status = 0xC0 or (channel0 and 0x0F)
    val statusHex = status.toString(16).padStart(2, '0').uppercase()

    fun line(btn: ChocolateButton, pcShown: Int): String {
        val sent = if (sendBaseZero) (pcShown - 1) else pcShown
        val dataHex = sent.toString(16).padStart(2, '0').uppercase()
        return btn.name + " -> PC " + pcShown + " (sent " + sent + "), MIDI bytes: [" +
            "0x" + statusHex + ", 0x" + dataHex + "] on CH" + ch
    }

    return listOf(
        line(ChocolateButton.A, 1),
        line(ChocolateButton.B, 2),
        line(ChocolateButton.C, 6),
        line(ChocolateButton.D, 7)
    )
}
