package com.example.katanachocolatecontroller

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import com.example.katanachocolatecontroller.ui.AppNav
import com.example.katanachocolatecontroller.ui.theme.KatanaChocolateControllerTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        vm.onBluetoothPermissionsResult(results)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ask for BT permissions up front (scan/connect).
        requestBtPermissionsIfNeeded()

        // Handle intent if we were launched by USB attach.
        intent?.let(vm::handleUsbIntent)

        setContent {
            KatanaChocolateControllerTheme {
                val ctx = LocalContext.current

                // Register USB attach/detach + permission receiver while UI is alive.
                DisposableEffect(Unit) {
                    val filter = IntentFilter().apply {
                        addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
                        addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
                        addAction(UsbKatanaManager.ACTION_USB_PERMISSION)
                    }

                    val receiver = object : BroadcastReceiver() {
                        override fun onReceive(context: Context, intent: Intent) {
                            vm.handleUsbIntent(intent)
                        }
                    }

                    if (android.os.Build.VERSION.SDK_INT >= 33) {
                            ctx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
                        } else {
                            @Suppress("DEPRECATION")
                            ctx.registerReceiver(receiver, filter)
                        }
                    onDispose {
                        ctx.unregisterReceiver(receiver)
                    }
                }

                LaunchedEffect(Unit) {
                    vm.refreshUsb()
                    vm.startBleAutoConnect()
                }

                AppNav(vm = vm)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        vm.handleUsbIntent(intent)
    }

    private fun requestBtPermissionsIfNeeded() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            perms += Manifest.permission.BLUETOOTH_SCAN
            perms += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            perms += Manifest.permission.BLUETOOTH
            perms += Manifest.permission.BLUETOOTH_ADMIN
        }
        permissionLauncher.launch(perms.toTypedArray())
    }
}
