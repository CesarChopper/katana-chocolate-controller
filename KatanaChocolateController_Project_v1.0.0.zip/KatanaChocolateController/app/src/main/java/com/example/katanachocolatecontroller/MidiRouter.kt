package com.example.katanachocolatecontroller

import android.os.SystemClock

class MidiRouter(
    private val settings: SettingsStore,
    private val usbOutputProvider: () -> MidiOut?,
    private val log: (String) -> Unit
) {
    private val lastTriggerMs = mutableMapOf<ChocolateButton, Long>()

    /**
     * Fixed mapping (human / base-1 numbers):
     * A -> 1, B -> 2, C -> 6, D -> 7
     */
    private val mappingBase1 = mapOf(
        ChocolateButton.A to 1,
        ChocolateButton.B to 2,
        ChocolateButton.C to 6,
        ChocolateButton.D to 7
    )

    suspend fun onIncomingProgramChange(pc: ProgramChange) {
        // M‑VAVE Chocolate default: A/B/C/D => Program Change 0/1/2/3 (bank 1).
        // Some setups use 1/2/3/4. We accept both.
        val btn = mapIncomingToButton(pc.program)
        if (btn == null) {
            log("BLE: ignoring incoming " + pc.toString())
            return
        }
        sendMappedProgramChange(btn, source = "BLE " + pc.toString())
    }

    private fun mapIncomingToButton(program: Int): ChocolateButton? {
        val idx = when (program) {
            in 0..3 -> program
            in 1..4 -> program - 1
            else -> return null
        }
        return ChocolateButton.entries[idx]
    }

    suspend fun sendMappedProgramChange(button: ChocolateButton, source: String) {
        val s = settings.snapshot()

        val now = SystemClock.elapsedRealtime()
        val last = lastTriggerMs[button] ?: 0L
        val debounce = s.debounceMs
        if (now - last < debounce) {
            log("Debounce: " + button.name + " (" + (now - last) + "ms < " + debounce + "ms) from " + source)
            return
        }
        lastTriggerMs[button] = now

        val out = usbOutputProvider()
        if (out == null) {
            log("USB: not ready, cannot send (" + button.name + ") from " + source)
            return
        }

        val displayPc = mappingBase1[button] ?: return
        val programToSend = if (s.sendBaseZero) (displayPc - 1) else displayPc

        val channel0 = (s.midiChannel - 1).coerceIn(0, 3)
        val ok = out.sendProgramChange(channel0 = channel0, program = programToSend)

        val pcLabel = if (s.sendBaseZero) {
            displayPc.toString() + " (0x" + programToSend.toString(16).padStart(2, '0').uppercase() + ")"
        } else {
            displayPc.toString()
        }

        if (ok) {
            log("Sent: Button " + button.name + " -> PC " + pcLabel + " on CH" + (channel0 + 1) + " (source=" + source + ")")
        } else {
            log("Send FAILED: Button " + button.name + " -> PC " + pcLabel + " on CH" + (channel0 + 1) + " (source=" + source + ")")
        }
    }

    fun mappingTableLines(sendBaseZero: Boolean, midiChannel: Int): List<String> {
        val ch = midiChannel.coerceIn(1, 4)
        val status = 0xC0 or ((ch - 1) and 0x0F)
        val statusHex = status.toString(16).padStart(2, '0').uppercase()
        return ChocolateButton.entries.map { btn ->
            val displayPc = mappingBase1[btn] ?: 0
            val programToSend = if (sendBaseZero) displayPc - 1 else displayPc
            val dataHex = programToSend.toString(16).padStart(2, '0').uppercase()
            "Button " + btn.name +
                " -> Program Change: status=0x" + statusHex +
                " data=0x" + dataHex +
                " (PC shown=" + displayPc + ", sent=" + programToSend + ") on CH" + ch
        }
    }
}
