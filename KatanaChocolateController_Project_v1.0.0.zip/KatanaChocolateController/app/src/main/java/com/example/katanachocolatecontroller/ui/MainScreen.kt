package com.example.katanachocolatecontroller.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.katanachocolatecontroller.BleState
import com.example.katanachocolatecontroller.ChocolateButton
import com.example.katanachocolatecontroller.MainViewModel
import com.example.katanachocolatecontroller.OutputMode
import com.example.katanachocolatecontroller.UsbState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    vm: MainViewModel,
    onOpenSettings: () -> Unit
) {
    val ui by vm.ui.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Katana Chocolate Controller") },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            StatusCard(title = "BLE-MIDI (Chocolate)") {
                Text(text = bleStateText(ui.bleState), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("Last RX: " + ui.lastBleMessage)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.scanBle() }) { Text("Scan/Connect") }
                    Button(onClick = { vm.disconnectBle() }) { Text("Disconnect") }
                }
            }

            StatusCard(title = "USB OTG (Katana)") {
                Text(text = usbStateText(ui.usbState), fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("Output mode: " + outputModeText(ui.outputMode))
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.refreshUsb() }) { Text("Refresh USB") }
                }
            }

            StatusCard(title = "Test (Send A/B/C/D)") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.onTestButton(ChocolateButton.A) }) { Text("A") }
                    Button(onClick = { vm.onTestButton(ChocolateButton.B) }) { Text("B") }
                    Button(onClick = { vm.onTestButton(ChocolateButton.C) }) { Text("C") }
                    Button(onClick = { vm.onTestButton(ChocolateButton.D) }) { Text("D") }
                }
                Spacer(Modifier.height(10.dp))
                Text(
                    "Current settings: CH" + ui.settings.midiChannel +
                        ", sendBaseZero=" + ui.settings.sendBaseZero +
                        ", debounce=" + ui.settings.debounceMs + "ms",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            StatusCard(title = "Event log (last 30)") {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                ) {
                    items(ui.eventLog) { line ->
                        Text(line, style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusCard(title: String, content: @Composable () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

private fun bleStateText(st: BleState): String =
    when (st) {
        is BleState.Disconnected -> "Disconnected"
        is BleState.Scanning -> "Scanning/Connecting…"
        is BleState.Connected -> "Connected: " + st.name + " (" + st.address + ")"
        is BleState.Error -> "Error: " + st.message
    }

private fun usbStateText(st: UsbState): String =
    when (st) {
        is UsbState.NotDetected -> "Not detected"
        is UsbState.NoPermission -> "No permission (tap Refresh USB, accept prompt)"
        is UsbState.Connected -> "Connected: " + st.description
        is UsbState.Error -> "Error: " + st.message
    }

private fun outputModeText(m: OutputMode): String =
    when (m) {
        OutputMode.None -> "None"
        OutputMode.AndroidMidiApi -> "Android MIDI API"
        OutputMode.UsbHostDriver -> "USB Host driver"
    }
