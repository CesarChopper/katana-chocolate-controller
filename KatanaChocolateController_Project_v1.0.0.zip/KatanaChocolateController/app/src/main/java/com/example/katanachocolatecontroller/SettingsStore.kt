package com.example.katanachocolatecontroller

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.first

private val Context.dataStore by preferencesDataStore(name = "katana_settings")

data class SettingsState(
    val midiChannel: Int = 1,            // 1..4
    val sendBaseZero: Boolean = true,    // default ON to match "1 (00H)" style
    val debounceMs: Long = 120L
)

class SettingsStore(private val ctx: Context) {
    private object Keys {
        val MIDI_CH = intPreferencesKey("midi_ch")
        val SEND_BASE_ZERO = booleanPreferencesKey("send_base_zero")
        val DEBOUNCE_MS = longPreferencesKey("debounce_ms")
        val LAST_BLE_ADDR = stringPreferencesKey("last_ble_addr")
    }

    val state: Flow<SettingsState> = ctx.dataStore.data.map { p ->
        SettingsState(
            midiChannel = p[Keys.MIDI_CH] ?: 1,
            sendBaseZero = p[Keys.SEND_BASE_ZERO] ?: true,
            debounceMs = p[Keys.DEBOUNCE_MS] ?: 120L
        )
    }

    suspend fun setMidiChannel(ch: Int) {
        ctx.dataStore.edit { it[Keys.MIDI_CH] = ch.coerceIn(1, 4) }
    }

    suspend fun setSendBaseZero(v: Boolean) {
        ctx.dataStore.edit { it[Keys.SEND_BASE_ZERO] = v }
    }

    suspend fun setDebounceMs(ms: Long) {
        ctx.dataStore.edit { it[Keys.DEBOUNCE_MS] = ms.coerceIn(80L, 150L) }
    }

    suspend fun setLastBleAddress(addr: String) {
        ctx.dataStore.edit { it[Keys.LAST_BLE_ADDR] = addr }
    }

    suspend fun getLastBleAddress(): String? {
        return ctx.dataStore.data.map { it[Keys.LAST_BLE_ADDR] }.firstOrNull()
    }

    suspend fun snapshot(): SettingsState {
        return state.first()
    }

    suspend fun resetDefaults() {
        ctx.dataStore.edit {
            it[Keys.MIDI_CH] = 1
            it[Keys.SEND_BASE_ZERO] = true
            it[Keys.DEBOUNCE_MS] = 120L
        }
    }
}
