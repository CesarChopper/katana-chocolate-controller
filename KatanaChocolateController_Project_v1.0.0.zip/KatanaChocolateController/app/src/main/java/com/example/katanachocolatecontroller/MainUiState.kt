package com.example.katanachocolatecontroller

data class MainUiState(
    val bleState: BleState = BleState.Disconnected,
    val usbState: UsbState = UsbState.NotDetected,
    val outputMode: OutputMode = OutputMode.None,
    val lastBleMessage: String = "—",
    val eventLog: List<String> = emptyList(),
    val settings: SettingsState = SettingsState()
)
