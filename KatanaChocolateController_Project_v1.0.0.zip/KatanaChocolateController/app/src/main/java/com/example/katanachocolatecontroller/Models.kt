package com.example.katanachocolatecontroller

enum class ChocolateButton { A, B, C, D }

enum class OutputMode { None, AndroidMidiApi, UsbHostDriver }

sealed class BleState {
    data object Disconnected : BleState()
    data object Scanning : BleState()
    data class Connected(val name: String, val address: String) : BleState()
    data class Error(val message: String) : BleState()
}

sealed class UsbState {
    data object NotDetected : UsbState()
    data object NoPermission : UsbState()
    data class Connected(val description: String) : UsbState()
    data class Error(val message: String) : UsbState()
}

data class ProgramChange(val channel0: Int, val program: Int) {
    override fun toString(): String = "PC ch${channel0 + 1} prog=$program"
}
