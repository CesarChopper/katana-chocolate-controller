# Builds a DEBUG APK.
# Requirements:
# - Android Studio installed (includes SDK)
# - local.properties present (Android Studio creates it after you open the project once)

$ErrorActionPreference = "Stop"

Set-Location (Join-Path $PSScriptRoot "..")

if (-not (Test-Path "local.properties")) {
  Write-Host "local.properties not found."
  Write-Host "Open the project once in Android Studio and it will generate local.properties automatically."
  Write-Host "Then re-run this script."
  exit 1
}

./gradlew.bat --no-daemon assembleDebug

Write-Host ""
Write-Host "APK generated at: app\build\outputs\apk\debug\app-debug.apk"
