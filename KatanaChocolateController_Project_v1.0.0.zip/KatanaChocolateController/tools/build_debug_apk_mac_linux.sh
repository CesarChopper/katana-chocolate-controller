#!/usr/bin/env bash
set -euo pipefail

# Builds a DEBUG APK.
# Requirements:
# - Android Studio installed (includes SDK)
# - ANDROID_HOME or sdk.dir set via local.properties

cd "$(dirname "$0")/.."

if [ ! -f "local.properties" ]; then
  echo "local.properties not found."
  echo "If you use Android Studio, open the project once and it will create local.properties automatically."
  echo "Or create it manually with: sdk.dir=/path/to/Android/Sdk"
  exit 1
fi

./gradlew --no-daemon assembleDebug

echo ""
echo "APK generated at: app/build/outputs/apk/debug/app-debug.apk"
